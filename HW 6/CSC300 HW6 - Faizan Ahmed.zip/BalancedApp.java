//Author: Faizan Ahmed
//CSC 300
//Homework #6

import java.util.Stack;
import java.util.Scanner;
import java.io.*;

public class BalancedApp  {

	public static void main(String[] args) throws FileNotFoundException {
		char lparen = '(';   char rparen = ')';
		char lbrack = '[';   char rbrack = ']';
		char lcurly = '{';   char rcurly = '}';

		//temp object - used for storing popped items from stack to print
		DelimPos temp;

		try { 
			Scanner fin = new Scanner(new FileReader("test4.txt"));

			Stack<DelimPos> st = new Stack<DelimPos>(); 

			//empty boundary for useDelimiter to read 1 character at a time from Scanner
			String empty = "";
			fin.useDelimiter(empty);  
			
			//print line count - 1 based
			int lcount = 1; 
			System.out.print(lcount + ". ");

			String s;
			while(fin.hasNext()) { 
				s = fin.next();

				//loop one character at a time
				char ch = 0;
				for (int i = 0; i < s.length(); i++) 
					ch = s.charAt(i);

				//incrementing line count - every newline
				if (ch == '\n' && fin.hasNext()) { 
					lcount++;  
					System.out.print("\n" + lcount + ". "); 
				}
				else {
					System.out.print(ch);
					
					//cases
					if (ch == lparen || ch == lbrack || ch == lcurly) { 
						st.push(new DelimPos(ch, lcount));
					}
					if (ch == rparen || ch == rbrack || ch == rcurly) { 
						//ERROR 1: If it is a closing symbol and the stack is empty, report an error
						if(st.isEmpty()) {
							System.out.println();
							System.out.println("\nError: Line " + lcount + ". Closing character '" + ch 
												+ "' , with no matching opening character.");
							return;
						}
						else {
							temp = st.pop();
							if(ch == rparen && temp.delim == lparen || 
								ch == rbrack && temp.delim == lbrack ||
								ch == rcurly && temp.delim == lcurly) {
							}
							//ERROR 2: If the symbol popped is not the corresponding opening symbol, then report an error
							else {
								System.out.println();
								System.out.println("\nError: Line " + lcount + ". Symbol '" + ch + 
													"' is the wrong closing symbol for char = '" + temp.delim + "', Line " + temp.lineNo); 
								return;
							}
						}
					}
				}  
			}
			//ERROR 3: At end of file, if the stack is not empty, report an error
			if(st.isEmpty() == false) { 
				temp = st.pop(); 
				System.out.println("\nError: At end of file, no closing symbol found for char = '" + 
									temp.delim + "', Line " + temp.lineNo);  
				return;
			} 
			//No Errors!
			System.out.println("\nInput is balanced.");

		//closing file
		fin.close(); 
		}
		catch (FileNotFoundException e){ 
			System.out.println(e);
			System.out.println("\nMake sure the file is in Java Project.");
			System.out.println("Or provide the whole filepath in the Scanner!");
		}
	}
}