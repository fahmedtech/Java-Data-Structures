//Author: Faizan Ahmed
//CSC 300
//Homework #6

import java.util.Stack;

public class DelimPos {
	
	//instance data members
	public char delim;
	public int lineNo;
	
	public DelimPos (char ch, int lno) {
		delim = ch;
		lineNo = lno;
	}
}