// File name: Inflation.java
// Author: Faizan Ahmed
// CSC 300 Homework #1
/* Description: The program asks for the cost of the item,
the number of years from now that the item will be purchased, 
and the rate of inflation */

import java.util.Scanner;

public class Inflation 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
	    
		double cost; int year; double rate;
		
		System.out.print("Enter the cost, number of years and inflation rate: ");
		cost = in.nextDouble();
		year = in.nextInt();
		rate = in.nextDouble();
		
		System.out.printf("Year 0 ==> $%.2f \n", cost);
		
		double new_cost = cost;
		for (int i = 1; i < year; i++ )
		{
		
		new_cost = (new_cost * (1.0 + (rate/100)));
		 System.out.printf("Year %s ==> $%.2f \n", i ,new_cost );
		}
		
		new_cost = (new_cost * (1.0 + (rate/100)));
		
		System.out.println("== Final Result == \n");
		System.out.printf("This item of $%.2f will cost $%.2f after %s years", cost, new_cost , year );
	}
}
