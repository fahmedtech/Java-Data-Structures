// File name: FeetInchLoop.java
// Author: Faizan Ahmed
// CSC 300 Homework #1
/* Description: This program converts inches to feet by using loops with 
   repeated subtraction.
 */

import java.util.Scanner;

public class FeetInchLoop {

	public static void main(String[] args){

		Scanner in = new Scanner(System.in);
		String ans;

		int inch;

		System.out.println("-- Welcome to the Feet-Inch Converter !! --");

		do{

			System.out.print("Enter the original inches: ");
			inch = in.nextInt();

			int feet = 0;
			int dividend = 12;

			while (inch >= dividend ){
				inch = inch - dividend;
				feet++;
			}
			System.out.printf("** Equivalent feet/inches: %d feet, %d inches **\n", feet, inch);

			System.out.println("Do you want to continue (y/n)? ");
			ans = in.next();
		} while (ans.equals("y") || ans.equals("Y"));
		if (ans.equals("n")|| ans.equals("N")){
			System.out.println("-- Thank You. Good Bye! --");
		}

	}

}
