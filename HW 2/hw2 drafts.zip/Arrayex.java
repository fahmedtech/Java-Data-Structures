import java.util.Random;

// Author: Faizan Ahmed
// CSC 300 - Homework #2


public class Arrayex {

	public static void main(String[] args){

		// randomly generates 5 integers between 0 - 100
		final int LEN = 5;
		int[] arr = new int[LEN];
		Random rgen = new Random();

		for (int i=0; i < LEN; i++){
			int randInt = rgen.nextInt(100);
			arr[i] = randInt;
		}

		// calling the methods
		System.out.print("Random Array: ");
		printArray(arr);

		int max = findMax(arr);
		System.out.println("\nThe maximum is " + max + ".");

		int minIndex = findMinIndex(arr);
		System.out.println("The INDEX to the MINIMUM is " + minIndex + ".");

		System.out.print("Reversed Array: ");
		revArray(arr);
		printArray(arr);
		
	}

	// all four methods

	public static void printArray(int[] ar){
		for (int i=0; i < ar.length; i++)
			System.out.print(ar[i] + " ");
	}

	// returns the highest integer from the array
	public static int findMax(int[] ar){
		int max_2 = ar[0];
		for (int i=0; i < ar.length; i++){
			if (ar[i] > max_2)
				max_2 = ar[i];
		} return max_2;
	}

	// returns the index of the lowest integer - find the left most 
	public static int findMinIndex(int[] ar){
		int min = 0;
		for (int i=0; i < ar.length; i++){
			if (ar[min] > ar[i])
				min = i;
				//break;
		} return min;
	}

	// prints the reverse of array - calls on printArray method for print
	public static void revArray(int[] ar){
		for(int i=0, j = ar.length - 1; i < j; i++, j--){
			int swap = ar[i];
			ar[i] = ar[j];
			ar[j] = swap;
		}
	}
}
