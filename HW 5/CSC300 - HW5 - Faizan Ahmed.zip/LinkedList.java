//Author: Faizan Ahmed
//CSC 300
//Homework #5
//Feb 27 2015

import java.util.Iterator;

public class LinkedList<E extends Comparable<E>> implements Iterable<E>
{
	// instance data members of list
	private Node head; // reference to the first node
	private int N;     // number of elements stored in the list

	/*******************
	 * nested class Node
	 *******************/
	private class Node
	{
		// instance data members of Node
		public E item;
		public Node next;

		// constructors for Node
		public Node()
		{
			item = null;  next = null;
		}

		public Node(E e, Node ptr)
		{
			item = e;  next = ptr;
		}
	}// end class Node

	/***************************
	 * nested class ListIterator
	 ***************************/
	private class ListIterator implements Iterator<E>
	{
		// instance data member of ListIterator
		private Node current;

		// constructors for ListIterator
		public ListIterator()
		{
			current = head; // head in the enclosing list
		}

		public boolean hasNext()
		{
			return current != null;
		}

		public E next()
		{
			E ret = current.item;
			current = current.next;
			return ret;
		}

		public void remove() { /* omitted because optional */ }

	}// end class ListIterator

	/***** back to class LinkedList *******/
	public LinkedList()
	{
		head = null; N = 0;
	}

	public Iterator<E> iterator( )
	{
		return new ListIterator();
	}

	public void add(E e)
	{
		// This code will be edited during the class.
		// For now, it pushes a new node in the front.
		// But first check the parameter is null.. if so, throw an exception.
		if (e == null)
			throw new NullPointerException();

		// For now, the element is pushed in the front, and N is incremented.
		head = new Node(e, head);
		++N;
	}

	public void remove(E e)
	{
		// This code will be edited during the class.
		// Removes the node with the parameter item if it exists, and decrements N.
		// Does nothing if the item doesn't exist, or the list is empty.
		// Throws a NullPointerException if the parameter item is null.
	}

	public boolean isEmpty() { return N == 0; }
	public int size() { return N; }

	//********************************************
	//  WRITE YOUE CODE BELOW
	//********************************************

	public void append(E item)
	{
		if (item == null)
			throw new NullPointerException();
		
		else if (head == null)
			head = new Node(item, null);
		
		else{
			Node ptr = head;
			while(ptr.next != null)
				ptr = ptr.next;
			ptr.next = new Node(item, null);
		}
		N++;
	}

	public boolean contains(E item){
		//Node ptr = head;
		if (item == null)
			throw new NullPointerException();

		else{
			Node ptr;
			for (ptr = head; ptr != null; ptr = ptr.next) {
				if (ptr.item.equals(item))     
					return true; 
			}
			return false;
		}
	}

	public E get(int k){
		if(k <0 || k >= size())
			throw new IndexOutOfBoundsException("Index =" + k);

		else{
			Node ptr = head;
			for(int i=0; i < k; i++){
				ptr = ptr.next;
			}	
			return ptr.item;
		}
	}

	public void removeAt(int k){
		if(k <0 || k >= size())
			throw new IndexOutOfBoundsException("Index =" + k);

		else if (head == null)
			return;

		else {
			Node ptr = head, nextL=null;
			for(int i=0; i < k; i++){
				nextL = ptr;
				ptr = ptr.next; }

			if (nextL == null)
				head = ptr.next;
			else
				nextL.next = ptr.next;
		}
		N--;
	}

	public void clear(){
		head = null;
		N = 0;
	}
}
