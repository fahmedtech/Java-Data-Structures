//Author: Faizan Ahmed
//CSC 300 
//Homework #5
//Feb 27 2015

public class LLtest extends LinkedList{
	public static void main(String[] args){

		//creating a linked list 
		int[] numb = {4,8,2,7};
		LinkedList<Integer> llst = new LinkedList<Integer>();
		for(int n: numb)
			llst.add(n);

		//boundary case linked list
		int[] numb2 = {};
		LinkedList<Integer> llst2 = new LinkedList<Integer>();
		for(int n2: numb2)
			llst2.add(n2);

		//printing the actual list
		System.out.print("LIST 1 --> ");
		for(int list : llst)
			System.out.printf("%s ", list);

		System.out.println("\nLIST 2 --> ");
		for(int list2 : llst2)
			System.out.printf("%s ", list2);

		System.out.println("-----------------------------");

//Append Method() Tests
		System.out.println("----- Append Method()");
		try{
			llst.append(5);
			for(int listapp : llst)
				System.out.printf("%s ", listapp);
			System.out.println("-- 5 is appended to List 1.");

			llst.append(null);}catch(NullPointerException item){
				System.out.println("Error! NullPointerException is thrown in List 1.");
			}

		//testing linked list 2
		try{ llst2.append(9);
			for(int listapp2 : llst2)
				System.out.printf("%s ", listapp2);
			System.out.println("-- appended to empty List 2.");} catch(NullPointerException item){
				System.out.println("Error! NullPointerException is thrown." );
			}
		System.out.println("-----------------------------");

//Contains Method() Tests
		System.out.println("----- Contains Method()");
		try{
			System.out.println(llst.contains(8) + " -- 8 contains in List 1");
			System.out.println(llst2.contains(2) + " -- 2 doesn't contain in List 2."); 
			System.out.print(llst.contains(null));
		}catch (NullPointerException item){
			System.out.println("Error! NullPointerException is thrown in List 1.");
		}
		System.out.println("-----------------------------");

//Get Method() Tests
		System.out.println("----- Get Method()");
		try {
			System.out.println(llst.get(2) + " is at index of 2 in List 1");

			System.out.println(llst.get(-1));
		} catch (IndexOutOfBoundsException k){
			System.out.println("Error! IndexOutofBoundsException is thrown in List 1.");}

		//testing linked list 2
		try{System.out.println(llst2.get(1));}catch(IndexOutOfBoundsException k){
			System.out.println("Error! IndexOutofBoundsException is thrown in List 2.");}

		System.out.println("-----------------------------");

//removeAt Method() Tests
		System.out.println("----- removeAt Method()");
		try{
			llst.removeAt(2);
			for (int listrem: llst)
				System.out.printf("%s ", listrem);
			System.out.print(" -- Integer at Index 2 is removed in List 1.\n");

			llst.removeAt(-1);
		}catch (IndexOutOfBoundsException k){
			System.out.println("Error! IndexOutofBoundsException is thrown in List 1.");}

		//testing linked list 2
		try{llst2.removeAt(1);}catch(IndexOutOfBoundsException k){
			System.out.println("Error! IndexOutofBoundsException is thrown in List 2.");}
		System.out.println("-----------------------------");

//Clear Method() Tests
		System.out.println("----- Clear Method()");
		llst.clear();
		if (llst.isEmpty())
			System.out.println("List 1 is cleared");
		else{
			for (int nclear : llst)
				System.out.printf("%s ", nclear);
		}

		//testing linked list 2
		llst2.clear();
		if(llst2.isEmpty())
			System.out.println("List 2 is cleared");
		else{
			for(int nclear2 : llst2)
				System.out.printf("%s ", nclear2);
		}System.out.println("-----------------------------");

	}
}
